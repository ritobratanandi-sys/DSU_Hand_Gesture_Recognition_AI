import os
import sys
import urllib.request
import threading
import tkinter as tk
from tkinter import ttk, messagebox

import cv2
import numpy as np
import joblib
import mediapipe as mp
from mediapipe.tasks import python
from mediapipe.tasks.python import vision
from sklearn.ensemble import RandomForestClassifier
from PIL import Image, ImageTk

APP_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_FILE = os.path.join(APP_DIR, "hand_landmarker.task")
CLASSIFIER_FILE = os.path.join(APP_DIR, "gesture_classifier.pkl")
MODEL_URL = (
    "https://storage.googleapis.com/mediapipe-models/hand_landmarker/"
    "hand_landmarker/float16/1/hand_landmarker.task"
)

GESTURES = ["Open Palm", "Fist", "Thumbs Up", "Peace Sign", "One Finger"]
SAMPLES_PER_GESTURE = 30


def ensure_landmarker_file():
    if not os.path.exists(MODEL_FILE):
        urllib.request.urlretrieve(MODEL_URL, MODEL_FILE)


def make_detector():
    ensure_landmarker_file()
    options = vision.HandLandmarkerOptions(
        base_options=python.BaseOptions(model_asset_path=MODEL_FILE),
        running_mode=vision.RunningMode.IMAGE,
        num_hands=1
    )
    return vision.HandLandmarker.create_from_options(options)


def extract_features(detector, bgr):
    rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
    image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
    result = detector.detect(image)
    if not result.hand_landmarks:
        return None, None

    hand = result.hand_landmarks[0]
    points = np.array([[p.x, p.y, p.z] for p in hand], dtype=np.float32)

    # Normalize around the wrist and hand size.
    points -= points[0]
    scale = np.max(np.linalg.norm(points[:, :2], axis=1))
    if scale < 1e-6:
        return None, hand
    points /= scale
    return points.flatten(), hand


class GestureAI:
    def __init__(self, root):
        self.root = root
        self.root.title("GestureAI | Hand Gesture Recognition")
        self.root.geometry("1180x760")
        self.root.minsize(980, 650)
        self.root.configure(bg="#08111f")

        self.detector = None
        self.cap = None
        self.running = False
        self.dataset = []
        self.classifier = None
        self.collecting = False
        self.gesture_index = 0
        self.gesture_count = 0
        self.frame_counter = 0
        self.latest_frame = None
        self.photo = None

        self.status_var = tk.StringVar(value="Starting hand detector...")
        self.gesture_var = tk.StringVar(value="No gesture yet")
        self.confidence_var = tk.StringVar(value="—")
        self.progress_var = tk.StringVar(value="0 / 150 samples")
        self.mode_var = tk.StringVar(value="READY")

        self._build_ui()
        self.root.after(150, self._initialize)

    def _build_ui(self):
        style = ttk.Style()
        style.theme_use("clam")
        style.configure(
            "TButton", font=("Segoe UI", 10, "bold"),
            padding=10, background="#12334a", foreground="white"
        )
        style.map("TButton", background=[("active", "#17677a")])
        style.configure(
            "Horizontal.TProgressbar",
            troughcolor="#1a2a3e", background="#23c8b5",
            bordercolor="#1a2a3e", lightcolor="#23c8b5",
            darkcolor="#23c8b5"
        )

        header = tk.Frame(self.root, bg="#101e31", padx=26, pady=20)
        header.pack(fill="x", padx=20, pady=(20, 14))
        tk.Label(
            header, text="GESTURE", fg="#f4f8ff", bg="#101e31",
            font=("Segoe UI", 25, "bold")
        ).pack(side="left")
        tk.Label(
            header, text="AI", fg="#23c8b5", bg="#101e31",
            font=("Segoe UI", 25, "bold")
        ).pack(side="left")
        tk.Label(
            header, text="REAL-TIME HAND GESTURE RECOGNITION",
            fg="#9fb2c9", bg="#101e31", font=("Segoe UI", 10)
        ).pack(side="right", pady=10)

        body = tk.Frame(self.root, bg="#08111f")
        body.pack(fill="both", expand=True, padx=20, pady=4)

        left = tk.Frame(body, bg="#101e31", padx=16, pady=16)
        left.pack(side="left", fill="both", expand=True)

        tk.Label(
            left, text="LIVE CAMERA", bg="#101e31", fg="#dce8f7",
            font=("Segoe UI", 12, "bold")
        ).pack(anchor="w", pady=(0, 10))

        self.video_label = tk.Label(
            left, text="Camera preview will appear here",
            bg="#050a12", fg="#8da2bb",
            font=("Segoe UI", 12), width=70, height=25
        )
        self.video_label.pack(fill="both", expand=True)

        right = tk.Frame(body, bg="#101e31", width=330, padx=18, pady=16)
        right.pack(side="right", fill="y", padx=(14, 0))
        right.pack_propagate(False)

        tk.Label(
            right, text="RECOGNITION", bg="#101e31", fg="#dce8f7",
            font=("Segoe UI", 12, "bold")
        ).pack(anchor="w")

        tk.Label(
            right, textvariable=self.gesture_var, bg="#101e31",
            fg="#23c8b5", font=("Segoe UI", 21, "bold"),
            wraplength=280, justify="left"
        ).pack(anchor="w", pady=(18, 4))

        tk.Label(
            right, text="MODEL SCORE", bg="#101e31", fg="#8da2bb",
            font=("Segoe UI", 9, "bold")
        ).pack(anchor="w", pady=(18, 3))
        tk.Label(
            right, textvariable=self.confidence_var, bg="#101e31",
            fg="#f4f8ff", font=("Segoe UI", 17, "bold")
        ).pack(anchor="w")

        tk.Frame(right, bg="#26384e", height=1).pack(fill="x", pady=20)

        tk.Label(
            right, text="DATA COLLECTION", bg="#101e31",
            fg="#dce8f7", font=("Segoe UI", 12, "bold")
        ).pack(anchor="w")
        tk.Label(
            right, text="Collect 30 examples for each gesture.",
            bg="#101e31", fg="#9fb2c9", font=("Segoe UI", 9),
            wraplength=280, justify="left"
        ).pack(anchor="w", pady=(7, 12))

        self.progress = ttk.Progressbar(
            right, maximum=len(GESTURES) * SAMPLES_PER_GESTURE,
            style="Horizontal.TProgressbar"
        )
        self.progress.pack(fill="x")
        tk.Label(
            right, textvariable=self.progress_var, bg="#101e31",
            fg="#23c8b5", font=("Segoe UI", 10, "bold")
        ).pack(anchor="w", pady=(7, 12))

        self.collect_btn = ttk.Button(
            right, text="START AUTO COLLECTION",
            command=self.start_collection
        )
        self.collect_btn.pack(fill="x", pady=5)

        self.train_btn = ttk.Button(
            right, text="TRAIN MODEL",
            command=self.train_model
        )
        self.train_btn.pack(fill="x", pady=5)

        self.load_btn = ttk.Button(
            right, text="LOAD SAVED MODEL",
            command=self.load_model
        )
        self.load_btn.pack(fill="x", pady=5)

        self.reset_btn = ttk.Button(
            right, text="RESET DATASET",
            command=self.reset_dataset
        )
        self.reset_btn.pack(fill="x", pady=5)

        tk.Frame(right, bg="#26384e", height=1).pack(fill="x", pady=18)

        tk.Label(
            right, text="SYSTEM STATUS", bg="#101e31",
            fg="#8da2bb", font=("Segoe UI", 9, "bold")
        ).pack(anchor="w")
        tk.Label(
            right, textvariable=self.status_var, bg="#101e31",
            fg="#dce8f7", font=("Segoe UI", 9),
            wraplength=280, justify="left"
        ).pack(anchor="w", pady=(7, 0))

        footer = tk.Label(
            self.root,
            text="MediaPipe Hand Landmarker  •  Random Forest  •  OpenCV",
            bg="#08111f", fg="#627891", font=("Segoe UI", 9)
        )
        footer.pack(pady=(8, 14))

    def _initialize(self):
        try:
            self.detector = make_detector()
            self.cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
            if not self.cap.isOpened():
                self.cap = cv2.VideoCapture(0)
            if not self.cap.isOpened():
                raise RuntimeError(
                    "Could not open webcam. Close apps using the camera "
                    "and check Windows camera permissions."
                )
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
            self.running = True
            self.status_var.set("Camera connected. Show your hand.")
            self._update_frame()
        except Exception as exc:
            self.status_var.set(str(exc))
            messagebox.showerror("Startup problem", str(exc))

    def start_collection(self):
        if self.detector is None or not self.running:
            messagebox.showwarning("Camera not ready", "Wait for the camera to connect.")
            return
        self.dataset = []
        self.gesture_index = 0
        self.gesture_count = 0
        self.frame_counter = 0
        self.collecting = True
        self.classifier = None
        self.progress["value"] = 0
        self.progress_var.set("0 / 150 samples")
        self.status_var.set(
            "Show OPEN PALM. Keep it visible and slowly vary its position."
        )
        self.gesture_var.set("Collecting: Open Palm")
        self.confidence_var.set("Collecting samples…")

    def train_model(self):
        if len(self.dataset) == 0:
            messagebox.showinfo("No data", "Collect gesture samples first.")
            return
        labels = [item[1] for item in self.dataset]
        missing = [g for g in GESTURES if labels.count(g) < 2]
        if missing:
            messagebox.showwarning(
                "Not enough samples",
                "Collect at least 2 samples for every gesture. Missing: "
                + ", ".join(missing)
            )
            return
        X = np.array([item[0] for item in self.dataset])
        y = np.array(labels)
        self.classifier = RandomForestClassifier(
            n_estimators=200,
            max_features="sqrt",
            class_weight="balanced",
            random_state=42
        )
        self.classifier.fit(X, y)
        joblib.dump(self.classifier, CLASSIFIER_FILE)
        self.status_var.set(
            f"Model trained on {len(self.dataset)} samples and saved locally."
        )
        self.gesture_var.set("Model ready")
        self.confidence_var.set("Ready for live testing")
        messagebox.showinfo(
            "Training complete",
            f"Model trained using {len(self.dataset)} samples.\n"
            "Try each gesture in front of the camera."
        )

    def load_model(self):
        if not os.path.exists(CLASSIFIER_FILE):
            messagebox.showwarning(
                "No saved model",
                "Train a model first. The saved model will appear here."
            )
            return
        try:
            self.classifier = joblib.load(CLASSIFIER_FILE)
            self.status_var.set("Saved classifier loaded.")
            self.gesture_var.set("Model ready")
            self.confidence_var.set("Ready for live testing")
        except Exception as exc:
            messagebox.showerror("Load error", str(exc))

    def reset_dataset(self):
        self.collecting = False
        self.dataset = []
        self.gesture_index = 0
        self.gesture_count = 0
        self.progress["value"] = 0
        self.progress_var.set("0 / 150 samples")
        self.status_var.set("Dataset cleared. Start a new collection.")
        self.gesture_var.set("No gesture yet")
        self.confidence_var.set("—")

    def _update_frame(self):
        if not self.running or self.cap is None:
            return

        ok, frame = self.cap.read()
        if ok:
            frame = cv2.flip(frame, 1)
            features, landmarks = extract_features(self.detector, frame)

            if landmarks:
                h, w = frame.shape[:2]
                for point in landmarks:
                    x, y = int(point.x * w), int(point.y * h)
                    cv2.circle(frame, (x, y), 4, (35, 200, 181), -1)

            if self.collecting:
                self._collect(features)
                if self.collecting:
                    label = GESTURES[self.gesture_index]
                    cv2.putText(
                        frame, f"COLLECTING: {label}",
                        (15, 35), cv2.FONT_HERSHEY_SIMPLEX,
                        0.75, (35, 220, 190), 2
                    )

            elif self.classifier is not None and features is not None:
                row = np.array(features).reshape(1, -1)
                probs = self.classifier.predict_proba(row)[0]
                best = int(np.argmax(probs))
                label = self.classifier.classes_[best]
                score = float(probs[best])
                self.gesture_var.set(label)
                self.confidence_var.set(f"{score * 100:.1f}% model score")
                cv2.putText(
                    frame, f"{label}  {score * 100:.0f}%",
                    (15, 35), cv2.FONT_HERSHEY_SIMPLEX,
                    0.8, (35, 220, 190), 2
                )
            elif landmarks is None:
                if not self.collecting:
                    self.gesture_var.set("No hand detected")

            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            image = Image.fromarray(rgb)
            image.thumbnail((760, 560))
            self.photo = ImageTk.PhotoImage(image=image)
            self.video_label.configure(image=self.photo, text="")

        self.root.after(25, self._update_frame)

    def _collect(self, features):
        if features is None:
            self.status_var.set("No hand detected. Keep your full hand in view.")
            return

        self.frame_counter += 1
        # Sample every 5th frame to reduce near-duplicate frames.
        if self.frame_counter % 5 != 0:
            return

        label = GESTURES[self.gesture_index]
        self.dataset.append((features.copy(), label))
        self.gesture_count += 1

        total = len(self.dataset)
        self.progress["value"] = total
        self.progress_var.set(f"{total} / 150 samples")
        self.status_var.set(
            f"Collecting {label}: {self.gesture_count}/{SAMPLES_PER_GESTURE}. "
            "Move your hand slightly between samples."
        )
        self.gesture_var.set(f"Collecting: {label}")

        if self.gesture_count >= SAMPLES_PER_GESTURE:
            self.gesture_index += 1
            self.gesture_count = 0
            if self.gesture_index >= len(GESTURES):
                self.collecting = False
                self.status_var.set(
                    "All five gestures collected. Press TRAIN MODEL."
                )
                self.gesture_var.set("Collection complete")
                self.confidence_var.set("150 samples collected")
                messagebox.showinfo(
                    "Collection complete",
                    "Collected 30 samples per gesture.\n"
                    "Press TRAIN MODEL to train your classifier."
                )
            else:
                next_gesture = GESTURES[self.gesture_index]
                self.status_var.set(
                    f"Now show {next_gesture}. Keep it visible and vary position."
                )
                self.gesture_var.set(f"Next: {next_gesture}")

    def close(self):
        self.running = False
        self.collecting = False
        if self.cap is not None:
            self.cap.release()
        if self.detector is not None:
            self.detector.close()
        self.root.destroy()


def main():
    root = tk.Tk()
    app = GestureAI(root)
    root.protocol("WM_DELETE_WINDOW", app.close)
    root.mainloop()


if __name__ == "__main__":
    main()
