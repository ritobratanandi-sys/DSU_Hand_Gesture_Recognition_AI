GestureAI for Windows
=====================

This is a local Windows desktop app. It uses your laptop webcam directly.

RECOMMENDED:
- Windows 10 or 11
- Python 3.11 (64-bit)
- Internet connection for the first launch (downloads the MediaPipe hand model)

SETUP:
1. Install Python 3.11 (64-bit) from https://www.python.org/downloads/
   During installation, enable "Add Python to PATH".
2. Extract this ZIP to a normal folder, such as Desktop\GestureAI_Windows.
3. Open that folder in File Explorer.
4. Click the address bar, type cmd, and press Enter.
5. Run these commands:

   py -3.11 -m venv .venv
   .venv\Scripts\activate
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   python gesture_ai_app.py

USING THE APP:
1. Wait for "Camera connected".
2. Click START AUTO COLLECTION.
3. Show each gesture when the app prompts you.
4. Keep the hand visible and move it slightly between captured samples.
5. After 150 samples are collected, click TRAIN MODEL.
6. Test the five gestures in front of the camera.
7. The classifier is saved as gesture_classifier.pkl.

GESTURES:
- Open Palm
- Fist
- Thumbs Up
- Peace Sign
- One Finger

NOTES:
- The app does not upload webcam images; processing happens locally.
- The first run downloads hand_landmarker.task into this folder.
- Model score is a Random Forest score, not a guarantee of correctness.
- This is a learning prototype. Results depend on lighting, camera angle,
  hand visibility, and the quality/variety of collected samples.
- Close Zoom/Meet/Camera if they are already using the webcam.
